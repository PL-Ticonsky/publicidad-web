---
name: Taller Editorial
colors:
  surface: '#faf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#faf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f0'
  surface-container: '#efeeea'
  surface-container-high: '#e9e8e4'
  surface-container-highest: '#e3e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#5b403d'
  inverse-surface: '#2f312e'
  inverse-on-surface: '#f2f1ed'
  outline: '#8f6f6c'
  outline-variant: '#e4beba'
  surface-tint: '#ba1a20'
  primary: '#af101a'
  on-primary: '#ffffff'
  primary-container: '#d32f2f'
  on-primary-container: '#fff2f0'
  inverse-primary: '#ffb3ac'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#59584e'
  on-tertiary: '#ffffff'
  tertiary-container: '#727066'
  on-tertiary-container: '#f9f5e8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ac'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#930010'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e6e2d6'
  tertiary-fixed-dim: '#cac6bb'
  on-tertiary-fixed: '#1d1c14'
  on-tertiary-fixed-variant: '#48473e'
  background: '#faf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e3e2df'
typography:
  display-lg:
    fontFamily: Bodoni Moda
    fontSize: 72px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 40px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  container-max: 1280px
---

## Brand & Style
The design system reflects a "modern print workshop" aesthetic, merging 20 years of Colombian industrial heritage with high-end editorial precision. The visual narrative moves away from generic digital interfaces toward a tactile, physical experience rooted in the craft of ink on paper.

The personality is **authoritative, tactile, and structured**. It utilizes a hybrid of **Minimalism** and **Modern Industrial** styles, characterized by rigorous grid systems, high-contrast layouts, and subtle nods to the printing process. The goal is to evoke the feeling of a premium physical catalog where every millimeter is intentional.

- **Editorial Rigor:** Content is organized with clear hierarchies, using whitespace as a functional tool rather than just "empty" space.
- **Industrial Precision:** Incorporation of technical motifs—crop marks, registration crosshairs, and hairline dividers—to reinforce the company's production expertise.
- **Heritage Modernized:** A sophisticated balance that respects decades of experience while appearing cutting-edge through bold typographic choices and fluid transitions.

## Colors
The palette is inspired by natural paper stocks and traditional ink pigments.

- **Base (#FDFCF8):** A warm, off-white "uncoated paper" surface that reduces digital eye strain and provides a premium, organic foundation.
- **Ink (#1A1A1A):** A deep, near-black used for all primary typography and structural lines. It should feel like high-density black ink.
- **Signal Red (#D32F2F):** A single, high-energy accent used for calls to action, price points, and critical information. It mimics the "marking pen" used in quality control.
- **Muted Stone (#E0DCD0):** Used for secondary backgrounds, borders, and subtle textures to provide depth without breaking the minimal aesthetic.

## Typography
The typographic system pairs the high-contrast elegance of an editorial serif with the functional clarity of a contemporary grotesque.

- **Display & Headlines:** Use **Bodoni Moda**. Its sharp serifs and extreme stroke contrast mirror the precision of high-end printing. Use for large-scale product names and section headers.
- **Body Text:** Use **Hanken Grotesk**. A clean, neutral sans-serif that ensures maximum readability for product specifications and company history.
- **Technical Labels:** Use **JetBrains Mono**. This monospaced font is used for SKU numbers, dimensions, and production data, reinforcing the "workshop" and "industrial" theme.

## Layout & Spacing
This design system utilizes a **Fixed Grid** model based on a 12-column structure for desktop and a 4-column structure for mobile.

- **Grid Lines:** Layout divisions are often marked by 1px "Ink" borders, mimicking the structure of a technical blueprint or a print layout sheet.
- **Rhythm:** A 4px baseline grid ensures vertical harmony. Spacing should be used in multiples of 8px (8, 16, 24, 32, 48, 64) to maintain a disciplined, industrial feel.
- **Margins:** Large horizontal margins on desktop create a "centered-folio" look, emphasizing quality over quantity.
- **White Space:** Use generous "safe areas" around high-quality product imagery to allow the photography to function as an editorial centerpiece.

## Elevation & Depth
In keeping with the print aesthetic, the design system avoids shadows and artificial blurs. Depth is achieved through **Tonal Layering** and **Bold Outlines**.

- **Flat Construction:** No drop shadows are used. Depth is communicated by stacking elements with 1px solid borders.
- **Overlays:** Modals and menus use solid "Ink" backgrounds or "Base" backgrounds with 1px borders, creating a clear "sheet on sheet" metaphor.
- **Halftone Textures:** Use subtle halftone dot patterns (in 5-10% opacity Ink) on secondary background layers to suggest the physical printing process.
- **Crop Marks:** Decorative 10px hairline "L" shapes should be used in the corners of primary containers or image blocks to signify "ready for production."

## Shapes
Shapes are predominantly **sharp and geometric** to reflect industrial cutting and precision.

- **Corners:** Standard buttons and containers use a 0px (sharp) or 4px (soft) radius. Never exceed 4px; the goal is a "trimmed paper" look, not a "plastic" look.
- **Dividers:** Use 1px solid lines for all separations. Vertical and horizontal lines should meet at 90-degree angles without rounding at the intersection.
- **Image Treatment:** Photography should be kept in strict rectangular ratios (1:1, 4:5, or 16:9). No circular avatars or organic blobs.

## Components
- **Buttons:**
  - **Primary:** Solid "Ink" background with "Base" text. 0px corner radius. On hover, shifts to "Signal Red."
  - **Secondary:** 1px "Ink" border, no fill, "Ink" text. On hover, fills with "Ink" and changes text to "Base."
- **Inputs:** 1px "Ink" bottom border only (no full box) for a minimalist stationery feel. Labels use the "Label-SM" mono font above the field.
- **Cards:** No shadows. Defined by 1px "Ink" borders. The header of the card should be separated from the body by a horizontal hairline.
- **Chips/Tags:** Small rectangular blocks with "JetBrains Mono" text. Use "Signal Red" for status indicators (e.g., "In Production").
- **Product Lists:** Organized in a strict grid. Each item is separated by hairlines, creating a table-like appearance that feels like a production manifest.
- **Registration Marks:** Use a small circular crosshair icon in the corners of major section transitions as a decorative brand element.